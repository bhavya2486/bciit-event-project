from django.contrib import admin
from testapp import views
from django.urls import path

urlpatterns = [
 
    path('admin/', admin.site.urls),
    path('',views.collectformdata),
    path('check/',views.check_user),

]