from django.db import models
from datetime import date
from django.contrib.auth.hashers import make_password, check_password
# Create your models here.
class User(models.Model):
      Name=models.CharField(max_length=70)
      Email=models.EmailField(max_length=50)
      Password=models.CharField(max_length=50)
      Date=models.DateField(default=date(2024,1,1))

      def save(self, *args, **kwargs):
        # Hash the password before saving
        if not self.pk:  # Only hash if the user is being created
            self.password = make_password(self.password)
        super().save(*args, **kwargs)

      def check_password(self, raw_password):
        return check_password(raw_password, self.password)
