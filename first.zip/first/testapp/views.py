from django.shortcuts import render
from datetime import datetime
from .forms import StudentRegistration
from .models import User
# Create your views here.
def collectformdata(request):
      if(request.method=='POST'):
            fm=StudentRegistration(request.POST)
            now = datetime.now()# Get the current date and time
            current_date = now.strftime("%Y-%m-%d")  # Example format: YYYY-MM-DD
            
            if(fm.is_valid()):
                  
                  print(fm)
                  nm=fm.cleaned_data['name']
                  em=fm.cleaned_data['email']
                  pm=fm.cleaned_data['password']
                  dt=current_date
                  reg=User(Name=nm,Email=em,Password=pm,Date=dt)
                  reg.save()
      else:
            fm=StudentRegistration()
            print("This is a GET Method")
      return render(request,'login.html',{'form':fm})

def login(request):
      data=User.objects.values('Name')
      name=request.POST.get('name')
      password=request.POST.get('password')
      data

def check_user(request):
    result = None
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        # Check if the username exists
        try:
            user = User.objects.filter('Email'==username)
            # Check the password
            if user.check_password(password):
                result = f'The user "{username}" exists and the password is correct.'
            else:
                result = f'The password for "{username}" is incorrect.'
        except User.DoesNotExist:
            result = f'The user "{username}" does not exist.'
    
    return render(request, 'signup.html', {'result': result})
